//
//  TabBarController.swift
//  WeChat
//
//  Created by 李秋 on 2017/7/6.
//  Copyright © 2017年 李秋. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        addChildViewControllers()
        tabBar.tintColor = UIColor(red: 9/255.0, green: 187/255.0, blue: 7/255.0, alpha: 1)
    }

    func addChildViewControllers() {
        setupOneChildViewController("微信", image: "tabbar_mainframe", selectedImage: "tabbar_mainframeHL", controller: ChatViewController())
        setupOneChildViewController("通讯录", image: "tabbar_contacts", selectedImage: "tabbar_contactsHL", controller: ContactsViewController())
        setupOneChildViewController("发现", image: "tabbar_discover", selectedImage: "tabbar_discoverHL", controller: DiscoverViewController())
        setupOneChildViewController("我", image: "tabbar_me", selectedImage: "tabbar_meHL", controller: MeViewController())
    }
    /*这里使用了‘_’,在swift中，它通常有以下几个作用
     1.只作为标记，使结构看起来更加清晰如：var money = 1_000_000 ,它等价于var money = 1000000
     2.任意匹配：某个区间范围上的任意匹配，如case (_,0) 和 case (0,_) 分别表示x轴和y轴，而这里的"_"就表示x或者y轴上面所有的点。比如for循环中只需要执行里面的内容，而又与循环变量没有关系。
         for _ in 1...8 {
          println("我循环打印的数和for循环里的参数没有关系")
          }
     3.起忽略作用：此处的用法就是忽略作用，在调用方法是，不用在方法里写上title的名字，而是直接写参数值
     */
    fileprivate func setupOneChildViewController(_ title: String, image: String, selectedImage: String, controller: UIViewController) {
        controller.tabBarItem.title = title
        controller.title = title
        controller.view.backgroundColor = UIColor.white
        controller.tabBarItem.image = UIImage(named: image)?.withRenderingMode(.alwaysOriginal)
        controller.tabBarItem.selectedImage = UIImage(named: selectedImage)?.withRenderingMode(.alwaysOriginal)
        let nav = UINavigationController.init(rootViewController: controller)
        addChildViewController(nav)
    }

   
}
