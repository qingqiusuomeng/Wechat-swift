//
//  ChatViewController.swift
//  WeChat
//
//  Created by 李秋 on 2017/7/6.
//  Copyright © 2017年 李秋. All rights reserved.
//

import UIKit

/*
 在oc中，引用代理方法的时候是在类名后面<代理方法1,代理方法2>，而swift中直接使用，分割
 */
class ChatViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    let imageArray = ["0.jpg","1.jpg","3.jpg"];
    let titleArray = ["东方时空","新闻联播","今日说法"]
    let messageArray = ["早上好","干嘛呢","你好"]
    let timeArray = ["星期一","星期二","星期三"]
    override func viewDidLoad() {
        super.viewDidLoad()
//swift中初始化方法直接使用.init
     let tableView = UITableView.init(frame: UIScreen.main.bounds, style: .plain)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.tableFooterView = UIView()
        view.addSubview(tableView)
    }

//swift中方法名使用func关键字
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //swift可以直接引用其他类的类名，因为swift没有头文件，所以不用导入.h文件，在项目中，默认项目建立好了桥接文件，用来过渡类与类的相互引用
        let cell = ChatMessageCell.init(style: .default, reuseIdentifier: nil)

        cell.headImage?.image = UIImage(named: imageArray[indexPath.row])
        cell.titleLabel?.text = titleArray[indexPath.row];
        cell.messageLabel?.text = messageArray[indexPath.row];
        cell.timeLabel?.text = timeArray[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
}
